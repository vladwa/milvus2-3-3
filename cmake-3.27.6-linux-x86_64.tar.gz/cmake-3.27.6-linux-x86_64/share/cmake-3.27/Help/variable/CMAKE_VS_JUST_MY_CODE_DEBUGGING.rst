CMAKE_VS_JUST_MY_CODE_DEBUGGING
-------------------------------

.. versionadded:: 3.15

Enable Just My Code with Visual Studio debugger.

This variable is used to initialize the :prop_tgt:`VS_JUST_MY_CODE_DEBUGGING`
property on all targets when they are created.  See that target property for
additional information.
