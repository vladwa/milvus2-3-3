IMPORTED_COMMON_LANGUAGE_RUNTIME
--------------------------------

.. versionadded:: 3.12

Property to define if the target uses ``C++/CLI``.

Ignored for non-imported targets.

See also the :prop_tgt:`COMMON_LANGUAGE_RUNTIME` target property.
